#include <stdlib.h>
#include <stdio.h>

#include <SDL2/SDL.h>

#include "game.h"
#include "updating.h"
#include "rendering.h"

int main(int argc, char *argv[])
{
	if (SDL_Init(SDL_INIT_VIDEO) != 0) {
		fprintf(stderr, "Error initializing SDL: %s\n", SDL_GetError());
		return EXIT_FAILURE;
	}

	SDL_DisplayMode display_mode;
	SDL_GetCurrentDisplayMode(0, &display_mode);
	
	SDL_Window *window = SDL_CreateWindow("window", 
										  SDL_WINDOWPOS_CENTERED, 
										  SDL_WINDOWPOS_CENTERED,
										  display_mode.w, display_mode.h,
										  SDL_WINDOW_FULLSCREEN);
	
	if (window == NULL) {
		fprintf(stderr, "Error creating window: %s\n", SDL_GetError());
		return EXIT_FAILURE;
	}

	SDL_Renderer *renderer = SDL_CreateRenderer(window, -1,
												SDL_RENDERER_ACCELERATED |
												SDL_RENDERER_PRESENTVSYNC);
	
	if (renderer == NULL) {
		fprintf(stderr, "Error creating renderer: %s\n", SDL_GetError());
		return EXIT_FAILURE;
	}

	game_t game = {
		.player = {
			.rect = { .x = 0, .y = 0, .w = 32, .h = 32 },
			.pos_x = 0.0f,
			.pos_y = 0.0f,
			.vel_x = 0.0f,
			.vel_y = 0.0f,
		},
		.tiles = NULL,
		.state = playing,
	};

	if (init_tile_vec(&game.tiles, 16) != 0) {
		fprintf(stderr, "Error initializing tile_vec\n");
		return EXIT_FAILURE;
	}
	
	if (push_tile_vec(&game.tiles, create_tile(0, 400, 32, 32)) != 0) {
		fprintf(stderr, "Error pushing back tile to tile_vec\n");
		return EXIT_FAILURE;
	}

	if (push_tile_vec(&game.tiles, create_tile(400, 400, 32, 32)) != 0) {
		fprintf(stderr, "Error pushing back tile to tile_vec\n");
		return EXIT_FAILURE;
	}

	while (game.state != quit) {
		SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
		SDL_RenderClear(renderer);
		update_game(&game);
		render_game(renderer, &game);
		SDL_RenderPresent(renderer);
	}

	free_tile_vec(&game.tiles);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	SDL_Quit();

	return EXIT_SUCCESS;
}
