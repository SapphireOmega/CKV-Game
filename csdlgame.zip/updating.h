#ifndef UPDATING_H_
#define UPDATING_H_

#include "game.h"

void update_game(game_t *game);

#endif // UPDATING_H_
