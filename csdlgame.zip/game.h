#ifndef GAME_H_
#define GAME_H_

#include "player.h"
#include "tile.h"

enum game_state {
	playing = 0,
	quit = 1,
};

typedef struct {
	player_t player;
	tile_vec_t tiles;
	enum game_state state;
} game_t;

#endif // GAME_H_
