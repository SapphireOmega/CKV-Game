#include "rendering.h"

const SDL_Color player_color = { .r = 0, .g = 0, .b = 0 };
const SDL_Color tile_color = { .r = 80, .g = 80, .b = 80 };

void render_player(SDL_Renderer *renderer, const player_t *player)
{
	SDL_SetRenderDrawColor(renderer,
						   player_color.r,
						   player_color.g,
						   player_color.b,
						   255);

	SDL_RenderDrawRect(renderer, &player->rect);
	SDL_RenderFillRect(renderer, &player->rect);
}

void render_tiles(SDL_Renderer *renderer, const tile_vec_t *tiles)
{
	SDL_SetRenderDrawColor(renderer,
						   tile_color.r,
						   tile_color.g,
						   tile_color.b,
						   255);

	for (int i = 0; i < tiles->used; i++) {
		SDL_RenderDrawRect(renderer, &tiles->vec[i]->rect);
		SDL_RenderFillRect(renderer, &tiles->vec[i]->rect);
	}
}

void render_playing_state(SDL_Renderer *renderer, const game_t *game)
{
	render_player(renderer, &game->player);
	if (game->tiles.vec != NULL)
		render_tiles(renderer, &game->tiles);
}

void render_game(SDL_Renderer *renderer, const game_t *game)
{
	switch (game->state) {
	case playing:
		render_playing_state(renderer, game);
		break;
	}
}
