#include "updating.h"

#define GRAV 0.2

void update_player(player_t *player)
{
	player->vel_y += GRAV;
	player->pos_x += player->vel_x;
	player->pos_y += player->vel_y;
	player->rect.x = (int)player->pos_x;
	player->rect.y = (int)player->pos_y;
}

void update_playing_state(game_t *game)
{
	SDL_Event event;
	while (SDL_PollEvent(&event)) {
		switch (event.type) {
		case SDL_QUIT:
			game->state = quit;
			break;
		case SDL_KEYDOWN:
			switch (event.key.keysym.sym) {
			case SDLK_ESCAPE:
				game->state = quit;
				break;
			}
			break;
		}
	}
	update_player(&game->player);
}

void update_game(game_t *game)
{
	switch (game->state) {
	case playing:
		update_playing_state(game);
		break;
	}
}
